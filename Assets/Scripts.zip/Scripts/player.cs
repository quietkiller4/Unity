using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class player : MonoBehaviour
{

    public float speed = 2.0f;

    Vector2 move_vector;
    Rigidbody my_rigid_body;

    // Start is called before the first frame update
    void Start()
    {
        print("Hello x");

        my_rigid_body = GetComponent<Rigidbody>();      // Do some error checking here??
    }

    // Update is called once per frame
    void Update()
    {
        //Vector3 velocity = (new Vector3(move_vector.x, 0, move_vector.y)).normalized * speed;
        //transform.Translate(velocity * Time.deltaTime, Space.World);
        //print(velocity);
    }

    public void fire(InputAction.CallbackContext context)
    {
        float button = context.ReadValue<float>();
        print("fire function: " + button);
    }

    public void move(InputAction.CallbackContext context)
    {
        move_vector = context.ReadValue<Vector2>();
        print("move function: " + move_vector);
    }

    // Best to do any Physics-related updates here rather than Update.
    private void FixedUpdate()
    {
        Vector3 velocity = (new Vector3(move_vector.x, 0, move_vector.y)).normalized * speed;
        //transform.Translate(velocity * Time.deltaTime, Space.World);

        my_rigid_body.velocity = velocity;      // No need for delta time (its handled internally) if we ever need it though it is Time.fixedDeltaTime
    }
}
